const axios = require("axios");
exports.handler = async (event) => {
  let body = '';
  try {
    var options = {
      method: 'GET',
      url: 'https://booking-com.p.rapidapi.com/v1/hotels/facilities',
      params: { locale: event.queryStringParameters.locale, hotel_id: event.queryStringParameters.hotelId },
      headers: {
        'x-rapidapi-host': 'booking-com.p.rapidapi.com',
        'x-rapidapi-key': process.env.rapidapikey
      }
    };

    const res = await axios(options);
    body = res.data;
    return {
      "statusCode": 200,
      "body": JSON.stringify(body),
    };


  }
  catch (e) {
    console.log(e);
    const response = {
      "statusCode": 400,
      "body": JSON.stringify(e),
    };
    return response;

  }



};
