//PUT /todos/{id} => API Gateway => Proxy Integration REST API
//Lamdba function

const AWS = require('aws-sdk');
const dynamo = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
    
    const userName = event.queryStringParameters.userName;
     var params = {
        TableName: 'BookmarkedHotels',
        //TableName: process.env.TODO_TABLE,
        Key: {username:userName }
    };

    const results = await dynamo.get(params).promise();
    console.log(results.Item);
    let hotelsList=[];
    const addedItem= JSON.parse(event.body);
    if(results.Item && results.Item.hotelsList){
      
      hotelsList=[...results.Item.hotelsList,addedItem];
      
    }else
    hotelsList.push(addedItem);

    console.log(hotelsList);
 
    const newItem ={
      username: userName,
      hotelsList: hotelsList
    }
    console.log(event.body);

    var params = {
      TableName : 'BookmarkedHotels',
      Item: newItem
    };
    
    const result = await dynamo.put(params).promise();
   

    
    const statusCode = 201
    
    const headers = { "Access-Control-Allow-Origin":"*" }
    
    const response = { statusCode, body:JSON.stringify(newItem.hotelsList), headers };

    return response;
};