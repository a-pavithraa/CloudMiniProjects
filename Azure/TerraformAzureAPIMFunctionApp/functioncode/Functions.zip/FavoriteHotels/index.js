const MongoClient = require('mongodb').MongoClient;

module.exports = async function (context, req) {   
    
    const URL = process.env.MONGODB_URL;
    const DATABASE_NAME = process.env.MONGODB_DATABASE_NAME;
    const COLLECTION_NAME = process.env.MONGODB_COLLECTION_NAME;
    const userName = req.query.userName;


    const connection = await MongoClient.connect(URL)
    const todoCollection = connection.db(DATABASE_NAME)
        .collection(COLLECTION_NAME)
    var query = { username: req.query.userName };
    const results = await todoCollection
        .find(query)
        .toArray();
    let hotelsList = [];   
    if (req.method == 'POST') {

        
        const addedItem = JSON.parse(req.body);
        if (results && results[0] && results[0].hotelsList) {

            hotelsList = [...results[0].hotelsList, addedItem];
            await todoCollection
                .updateOne(
                    { _id: results[0]._id },
                    {
                        $set: {
                            username: userName,
                            hotelsList: hotelsList
                        }
                    }
                );


        } else {
            hotelsList.push(addedItem);
            await todoCollection
                .insertOne({
                    username: userName,
                    hotelsList: hotelsList
                });

        }

    } else {
        if (results && results[0] && results[0].hotelsList)
            hotelsList = results[0].hotelsList;
    }

    await connection.close();


    context.res =  {
        body: JSON.stringify(hotelsList)
    };

}