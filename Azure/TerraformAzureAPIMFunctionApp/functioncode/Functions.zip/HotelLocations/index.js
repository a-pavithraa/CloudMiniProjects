const axios = require("axios");
module.exports = async function (context, req) {
    context.log('JavaScript HTTP trigger function processed a request.');


      var options = {
      method: 'GET',
      url: 'https://booking-com.p.rapidapi.com/v1/hotels/locations',
      
      params: { locale: req.query.locale, name: req.query.locationName },
      headers: {
        'x-rapidapi-host': 'booking-com.p.rapidapi.com',
        'x-rapidapi-key': process.env.rapidapikey
      }
    };

    const res = await axios(options);
   
    context.res = {
        // status: 200, /* Defaults to 200 */
        body: res.data
    };
}